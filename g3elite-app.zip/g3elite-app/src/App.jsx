import { useState, useMemo } from "react";

const PICK_TYPES = [
  "🏠 LOCAL + U3.5",
  "✈ VISITA + U3.5",
  "⚽ BTTS Sí",
  "📈 OVER 2.5",
  "🔒 UNDER 2.5/HTX",
];

function calcPick(row) {
  const { over_local, over_visit, btts_local, btts_visit, vic_local, vic_visit } = row;
  const media = row.goles_local !== "" && row.goles_visit !== ""
    ? (parseFloat(row.goles_local) + parseFloat(row.goles_visit)) / 2
    : null;
  const mediaVal = media !== null ? media : null;

  const filtroOK =
    over_local !== "" && over_visit !== "" &&
    btts_local !== "" && btts_visit !== "" &&
    vic_local !== "" && vic_visit !== "" &&
    mediaVal !== null && mediaVal < 2.5 &&
    parseFloat(over_local) < 45 && parseFloat(over_visit) < 45 &&
    parseFloat(btts_local) >= 40 && parseFloat(btts_visit) >= 40;

  let pick = "—";
  if (filtroOK) {
    const vl = parseFloat(vic_local), vv = parseFloat(vic_visit);
    const bl = parseFloat(btts_local), bv = parseFloat(btts_visit);
    const ol = parseFloat(over_local), ov = parseFloat(over_visit);
    if (vl >= 65 && vv <= 30) pick = "🏠 LOCAL + U3.5";
    else if (vl <= 30 && vv >= 65) pick = "✈ VISITA + U3.5";
    else if (bl >= 55 && bv >= 55) pick = "⚽ BTTS Sí";
    else if (ol >= 55 && ov >= 55) pick = "📈 OVER 2.5";
    else pick = "🔒 UNDER 2.5/HTX";
  }
  return { filtroOK, pick, media: mediaVal };
}

function calcBeneficio(cuota, stake, resultado) {
  if (!cuota || !stake || !resultado) return null;
  const c = parseFloat(cuota), s = parseFloat(stake);
  if (resultado === "W") return (c - 1) * s;
  if (resultado === "L") return -s;
  if (resultado === "V") return 0;
  return null;
}

const emptyRow = () => ({
  id: Date.now() + Math.random(),
  fecha: "", partido: "", liga: "", cuota: "", stake: "",
  resultado: "", goles_local: "", goles_visit: "",
  over_local: "", over_visit: "", btts_local: "", btts_visit: "",
  vic_local: "", vic_visit: "",
});

const STORAGE_KEY = "g3elite_picks";

function loadPicks() {
  try {
    const d = window.storage ? null : JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    return d && d.length ? d : [emptyRow()];
  } catch { return [emptyRow()]; }
}

// ─── Minimal numeric input ───────────────────────────────────────────────────
function Num({ val, onChange, placeholder = "0", suffix = "" }) {
  return (
    <div style={{ position: "relative", display: "inline-flex", alignItems: "center", width: "100%" }}>
      <input
        type="number"
        value={val}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          width: "100%", background: "transparent", border: "none",
          borderBottom: "1px solid rgba(255,255,255,0.15)",
          color: "#E8F4FD", fontSize: 12, textAlign: "center",
          padding: "3px 2px", outline: "none", fontFamily: "'DM Mono', monospace",
        }}
      />
      {suffix && <span style={{ color: "#7FA8C9", fontSize: 10, marginLeft: 2, whiteSpace: "nowrap" }}>{suffix}</span>}
    </div>
  );
}

function Txt({ val, onChange, placeholder }) {
  return (
    <input
      type="text"
      value={val}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      style={{
        width: "100%", background: "transparent", border: "none",
        borderBottom: "1px solid rgba(255,255,255,0.15)",
        color: "#E8F4FD", fontSize: 11, padding: "3px 2px",
        outline: "none", fontFamily: "'DM Sans', sans-serif",
      }}
    />
  );
}

export default function App() {
  const [picks, setPicks] = useState(loadPicks);
  const [tab, setTab] = useState("picks"); // picks | stats

  // persist
  const save = (newPicks) => {
    setPicks(newPicks);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(newPicks)); } catch {}
  };

  const updateRow = (id, field, val) => {
    save(picks.map(r => r.id === id ? { ...r, [field]: val } : r));
  };

  const addRow = () => save([...picks, emptyRow()]);
  const delRow = (id) => { if (picks.length > 1) save(picks.filter(r => r.id !== id)); };

  // ─── computed ─────────────────────────────────────────────────────────────
  const enriched = useMemo(() => picks.map(r => {
    const { filtroOK, pick, media } = calcPick(r);
    const ben = calcBeneficio(r.cuota, r.stake, r.resultado);
    return { ...r, filtroOK, pick, media, ben };
  }), [picks]);

  const stats = useMemo(() => {
    const played = enriched.filter(r => r.resultado);
    const won = played.filter(r => r.resultado === "W");
    const lost = played.filter(r => r.resultado === "L");
    const totalBen = played.reduce((s, r) => s + (r.ben ?? 0), 0);
    const totalStake = played.reduce((s, r) => s + (parseFloat(r.stake) || 0), 0);
    const roi = totalStake ? (totalBen / totalStake) * 100 : 0;
    const avgCuota = played.length
      ? played.reduce((s, r) => s + (parseFloat(r.cuota) || 0), 0) / played.length : 0;

    const byPick = PICK_TYPES.map(pt => {
      const rows = played.filter(r => r.pick === pt);
      return {
        name: pt,
        total: rows.length,
        won: rows.filter(r => r.resultado === "W").length,
        ben: rows.reduce((s, r) => s + (r.ben ?? 0), 0),
      };
    });

    // max win streak
    let maxStreak = 0, streak = 0;
    enriched.forEach(r => {
      if (r.resultado === "W") { streak++; maxStreak = Math.max(maxStreak, streak); }
      else if (r.resultado) streak = 0;
    });

    const last5 = [...enriched].filter(r => r.resultado).slice(-5).reverse();

    return { played: played.length, won: won.length, lost: lost.length, totalBen, roi, avgCuota, byPick, maxStreak, last5 };
  }, [enriched]);

  // ─── styles ───────────────────────────────────────────────────────────────
  const s = {
    app: {
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0B1626 0%, #0F2040 50%, #0B1A30 100%)",
      fontFamily: "'DM Sans', sans-serif",
      color: "#E8F4FD",
      padding: "0 0 40px 0",
    },
    header: {
      background: "linear-gradient(90deg, #0D3B26 0%, #1A5C38 60%, #0D3B26 100%)",
      borderBottom: "2px solid #27AE60",
      padding: "18px 24px 14px",
      display: "flex", alignItems: "center", justifyContent: "space-between",
    },
    title: {
      fontFamily: "'DM Mono', monospace",
      fontSize: 18, fontWeight: 700, letterSpacing: 2,
      color: "#fff", margin: 0,
      textShadow: "0 0 20px rgba(39,174,96,0.6)",
    },
    subtitle: { fontSize: 10, color: "#6FCF97", letterSpacing: 3, marginTop: 2 },
    tabs: {
      display: "flex", gap: 4, padding: "12px 24px 0",
      borderBottom: "1px solid rgba(255,255,255,0.07)",
    },
    tab: (active) => ({
      padding: "8px 20px", fontSize: 12, fontWeight: 600,
      letterSpacing: 1, cursor: "pointer", border: "none",
      background: active ? "rgba(39,174,96,0.15)" : "transparent",
      color: active ? "#6FCF97" : "#5A7F9A",
      borderBottom: active ? "2px solid #27AE60" : "2px solid transparent",
      borderRadius: "4px 4px 0 0", transition: "all .2s",
    }),
    section: { padding: "20px 16px" },
    card: {
      background: "rgba(255,255,255,0.03)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: 10, padding: "16px 20px", marginBottom: 16,
    },
    sectionTitle: {
      fontFamily: "'DM Mono', monospace",
      fontSize: 10, letterSpacing: 3, color: "#6FCF97",
      textTransform: "uppercase", marginBottom: 14,
      borderLeft: "3px solid #27AE60", paddingLeft: 8,
    },
    table: { width: "100%", borderCollapse: "collapse", fontSize: 11 },
    th: {
      background: "rgba(10,30,60,0.8)",
      color: "#7FA8C9", fontSize: 9, letterSpacing: 1,
      textTransform: "uppercase", padding: "8px 6px",
      textAlign: "center", borderBottom: "1px solid rgba(255,255,255,0.1)",
      fontFamily: "'DM Mono', monospace",
    },
    td: {
      padding: "5px 4px", textAlign: "center",
      borderBottom: "1px solid rgba(255,255,255,0.05)",
      verticalAlign: "middle",
    },
    addBtn: {
      background: "linear-gradient(135deg, #1A5C38, #27AE60)",
      color: "#fff", border: "none", borderRadius: 6,
      padding: "9px 20px", fontSize: 12, fontWeight: 700,
      cursor: "pointer", letterSpacing: 1,
      boxShadow: "0 4px 15px rgba(39,174,96,0.3)",
    },
    delBtn: {
      background: "rgba(192,57,43,0.15)", color: "#E74C3C",
      border: "1px solid rgba(231,76,60,0.3)", borderRadius: 4,
      padding: "2px 7px", fontSize: 11, cursor: "pointer",
    },
    badge: (ok) => ({
      padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 700,
      background: ok ? "rgba(39,174,96,0.15)" : "rgba(231,76,60,0.12)",
      color: ok ? "#6FCF97" : "#E74C3C",
      border: `1px solid ${ok ? "rgba(39,174,96,0.3)" : "rgba(231,76,60,0.2)"}`,
    }),
    benColor: (b) => b === null ? "#5A7F9A" : b > 0 ? "#6FCF97" : b < 0 ? "#E74C3C" : "#F39C12",
    kpiGrid: {
      display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))",
      gap: 12, marginBottom: 20,
    },
    kpi: (accent) => ({
      background: "rgba(255,255,255,0.03)",
      border: `1px solid ${accent}33`,
      borderTop: `3px solid ${accent}`,
      borderRadius: 8, padding: "14px 16px",
      display: "flex", flexDirection: "column", gap: 4,
    }),
    kpiVal: { fontSize: 22, fontWeight: 700, fontFamily: "'DM Mono', monospace" },
    kpiLabel: { fontSize: 9, color: "#5A7F9A", letterSpacing: 1, textTransform: "uppercase" },
    resultSel: {
      background: "transparent", border: "none",
      borderBottom: "1px solid rgba(255,255,255,0.15)",
      color: "#E8F4FD", fontSize: 11, textAlign: "center",
      outline: "none", cursor: "pointer", fontFamily: "'DM Mono', monospace",
      width: "100%",
    },
    scrollWrap: { overflowX: "auto", borderRadius: 8, border: "1px solid rgba(255,255,255,0.07)" },
  };

  const fmtEur = (v) => v === null ? "—" : `${v >= 0 ? "+" : ""}${v.toFixed(2)} €`;
  const fmtPct = (v) => `${v.toFixed(1)}%`;

  const resColor = (r) => r === "W" ? "#6FCF97" : r === "L" ? "#E74C3C" : r === "V" ? "#F39C12" : "#5A7F9A";

  // ─── render ───────────────────────────────────────────────────────────────
  return (
    <div style={s.app}>
      {/* Header */}
      <div style={s.header}>
        <div>
          <h1 style={s.title}>⚽ G3 ELITE TRACKER</h1>
          <p style={s.subtitle}>SISTEMA TERCERA DIVISIÓN · APUESTAS DE VALOR</p>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 20, color: stats.totalBen >= 0 ? "#6FCF97" : "#E74C3C", fontWeight: 700 }}>
            {fmtEur(stats.totalBen)}
          </div>
          <div style={{ fontSize: 9, color: "#5A7F9A", letterSpacing: 1 }}>BENEFICIO TOTAL</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={s.tabs}>
        {[["picks", "📋 PICKS"], ["stats", "📊 ESTADÍSTICAS"]].map(([k, label]) => (
          <button key={k} style={s.tab(tab === k)} onClick={() => setTab(k)}>{label}</button>
        ))}
      </div>

      {/* ── PICKS TAB ── */}
      {tab === "picks" && (
        <div style={s.section}>
          <div style={s.sectionTitle}>Registro de apuestas</div>
          <div style={s.scrollWrap}>
            <table style={s.table}>
              <thead>
                <tr>
                  {["Fecha","Partido","Liga","Cuota","Stake","Res.","Gol L","Gol V","O2.5 L%","O2.5 V%","BTTS L%","BTTS V%","Vic L%","Vic V%","Media","Filtro","Pick","Benef.",""].map((h, i) => (
                    <th key={i} style={s.th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {enriched.map((row, idx) => {
                  const rowBg = idx % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent";
                  return (
                    <tr key={row.id} style={{ background: rowBg }}>
                      <td style={s.td}><Txt val={row.fecha} onChange={v => updateRow(row.id, "fecha", v)} placeholder="dd/mm" /></td>
                      <td style={{ ...s.td, minWidth: 130 }}><Txt val={row.partido} onChange={v => updateRow(row.id, "partido", v)} placeholder="Local vs Visit." /></td>
                      <td style={{ ...s.td, minWidth: 80 }}><Txt val={row.liga} onChange={v => updateRow(row.id, "liga", v)} placeholder="Tercera G3" /></td>
                      <td style={{ ...s.td, minWidth: 52 }}><Num val={row.cuota} onChange={v => updateRow(row.id, "cuota", v)} placeholder="1.80" /></td>
                      <td style={{ ...s.td, minWidth: 52 }}><Num val={row.stake} onChange={v => updateRow(row.id, "stake", v)} placeholder="10" suffix="€" /></td>
                      <td style={{ ...s.td, minWidth: 52 }}>
                        <select
                          value={row.resultado}
                          onChange={e => updateRow(row.id, "resultado", e.target.value)}
                          style={{ ...s.resultSel, color: resColor(row.resultado) }}
                        >
                          <option value="">—</option>
                          <option value="W" style={{ color: "#6FCF97" }}>✅ W</option>
                          <option value="L" style={{ color: "#E74C3C" }}>❌ L</option>
                          <option value="V" style={{ color: "#F39C12" }}>🔁 V</option>
                        </select>
                      </td>
                      <td style={s.td}><Num val={row.goles_local} onChange={v => updateRow(row.id, "goles_local", v)} placeholder="0" /></td>
                      <td style={s.td}><Num val={row.goles_visit} onChange={v => updateRow(row.id, "goles_visit", v)} placeholder="0" /></td>
                      <td style={s.td}><Num val={row.over_local} onChange={v => updateRow(row.id, "over_local", v)} placeholder="40" suffix="%" /></td>
                      <td style={s.td}><Num val={row.over_visit} onChange={v => updateRow(row.id, "over_visit", v)} placeholder="40" suffix="%" /></td>
                      <td style={s.td}><Num val={row.btts_local} onChange={v => updateRow(row.id, "btts_local", v)} placeholder="50" suffix="%" /></td>
                      <td style={s.td}><Num val={row.btts_visit} onChange={v => updateRow(row.id, "btts_visit", v)} placeholder="50" suffix="%" /></td>
                      <td style={s.td}><Num val={row.vic_local} onChange={v => updateRow(row.id, "vic_local", v)} placeholder="50" suffix="%" /></td>
                      <td style={s.td}><Num val={row.vic_visit} onChange={v => updateRow(row.id, "vic_visit", v)} placeholder="30" suffix="%" /></td>
                      {/* Media */}
                      <td style={{ ...s.td, fontFamily: "'DM Mono', monospace", fontSize: 12, color: "#7FA8C9" }}>
                        {row.media !== null ? row.media.toFixed(2) : "—"}
                      </td>
                      {/* Filtro */}
                      <td style={s.td}>
                        <span style={s.badge(row.filtroOK)}>
                          {row.over_local === "" ? "?" : row.filtroOK ? "✅ OK" : "❌ NO"}
                        </span>
                      </td>
                      {/* Pick */}
                      <td style={{ ...s.td, minWidth: 110, fontSize: 10, color: row.filtroOK ? "#E8F4FD" : "#3A5A7A" }}>
                        {row.pick}
                      </td>
                      {/* Beneficio */}
                      <td style={{ ...s.td, fontFamily: "'DM Mono', monospace", fontWeight: 700, fontSize: 12, color: s.benColor(row.ben) }}>
                        {fmtEur(row.ben)}
                      </td>
                      <td style={s.td}>
                        <button style={s.delBtn} onClick={() => delRow(row.id)}>✕</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Add row + totals */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16 }}>
            <button style={s.addBtn} onClick={addRow}>+ Añadir pick</button>
            <div style={{ display: "flex", gap: 24, fontSize: 12 }}>
              <span style={{ color: "#6FCF97" }}>✅ {stats.won}W</span>
              <span style={{ color: "#E74C3C" }}>❌ {stats.lost}L</span>
              <span style={{ fontFamily: "'DM Mono', monospace", fontWeight: 700, color: s.benColor(stats.totalBen) }}>
                {fmtEur(stats.totalBen)}
              </span>
            </div>
          </div>

          {/* Leyenda filtro */}
          <div style={{ ...s.card, marginTop: 20, fontSize: 10, color: "#5A7F9A", lineHeight: 1.8 }}>
            <div style={s.sectionTitle}>Criterios filtro élite</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2px 24px" }}>
              <span>📉 Media Goles &lt; 2.5</span>
              <span>📊 Over2.5 Local/Visit. &lt; 45%</span>
              <span>⚽ BTTS Local/Visit. ≥ 40%</span>
              <span>🏠 LOCAL si Vic.L ≥ 65% y Vic.V ≤ 30%</span>
              <span>✈ VISITA si Vic.V ≥ 65% y Vic.L ≤ 30%</span>
              <span>⚽ BTTS si ambos BTTS ≥ 55%</span>
            </div>
          </div>
        </div>
      )}

      {/* ── STATS TAB ── */}
      {tab === "stats" && (
        <div style={s.section}>
          {/* KPIs */}
          <div style={s.sectionTitle}>Rendimiento general</div>
          <div style={s.kpiGrid}>
            {[
              { label: "Apuestas", val: stats.played, accent: "#3498DB", fmt: v => v },
              { label: "Ganadas", val: stats.won, accent: "#27AE60", fmt: v => v },
              { label: "Perdidas", val: stats.lost, accent: "#E74C3C", fmt: v => v },
              { label: "% Acierto", val: stats.played ? (stats.won / stats.played * 100) : 0, accent: "#F39C12", fmt: fmtPct },
              { label: "Beneficio", val: stats.totalBen, accent: stats.totalBen >= 0 ? "#27AE60" : "#E74C3C", fmt: fmtEur },
              { label: "ROI", val: stats.roi, accent: stats.roi >= 0 ? "#27AE60" : "#E74C3C", fmt: fmtPct },
              { label: "Racha Max W", val: stats.maxStreak, accent: "#9B59B6", fmt: v => `${v} ✅` },
              { label: "Cuota Media", val: stats.avgCuota, accent: "#1ABC9C", fmt: v => v.toFixed(2) },
            ].map(({ label, val, accent, fmt }) => (
              <div key={label} style={s.kpi(accent)}>
                <div style={{ ...s.kpiVal, color: accent }}>{fmt(val)}</div>
                <div style={s.kpiLabel}>{label}</div>
              </div>
            ))}
          </div>

          {/* Por tipo pick */}
          <div style={s.sectionTitle}>Rendimiento por tipo de pick</div>
          <div style={s.scrollWrap}>
            <table style={s.table}>
              <thead>
                <tr>
                  {["Tipo de Pick", "Apostadas", "Ganadas", "% Acierto", "Beneficio"].map(h => (
                    <th key={h} style={s.th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {stats.byPick.map((p, i) => (
                  <tr key={p.name} style={{ background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent" }}>
                    <td style={{ ...s.td, textAlign: "left", paddingLeft: 12, fontWeight: 600 }}>{p.name}</td>
                    <td style={{ ...s.td, fontFamily: "'DM Mono', monospace" }}>{p.total}</td>
                    <td style={{ ...s.td, fontFamily: "'DM Mono', monospace", color: "#6FCF97" }}>{p.won}</td>
                    <td style={{ ...s.td, fontFamily: "'DM Mono', monospace", color: "#F39C12" }}>
                      {p.total > 0 ? fmtPct(p.won / p.total * 100) : "—"}
                    </td>
                    <td style={{ ...s.td, fontFamily: "'DM Mono', monospace", fontWeight: 700, color: s.benColor(p.ben) }}>
                      {p.total > 0 ? fmtEur(p.ben) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Últimas 5 */}
          <div style={{ ...s.sectionTitle, marginTop: 24 }}>Últimas 5 apuestas</div>
          {stats.last5.length === 0
            ? <div style={{ color: "#3A5A7A", fontSize: 12, padding: 12 }}>Sin apuestas registradas aún.</div>
            : (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {stats.last5.map(r => (
                  <div key={r.id} style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.07)",
                    borderRadius: 8, padding: "10px 16px",
                    borderLeft: `3px solid ${resColor(r.resultado)}`,
                  }}>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{r.partido || "—"}</div>
                      <div style={{ fontSize: 10, color: "#5A7F9A", marginTop: 2 }}>
                        {r.pick} · cuota {r.cuota || "—"} · {r.liga || "—"}
                      </div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 14, fontWeight: 700, fontFamily: "'DM Mono', monospace", color: s.benColor(r.ben) }}>
                        {fmtEur(r.ben)}
                      </div>
                      <div style={{ fontSize: 11, color: resColor(r.resultado), fontWeight: 700 }}>
                        {r.resultado || "—"}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )
          }

          {/* Curva de beneficio mini */}
          {stats.played >= 2 && (() => {
            const benSeries = (() => {
              let acc = 0;
              return enriched.filter(r => r.resultado).map(r => { acc += r.ben ?? 0; return acc; });
            })();
            const min = Math.min(0, ...benSeries), max = Math.max(0, ...benSeries);
            const range = max - min || 1;
            const W = 400, H = 80;
            const pts = benSeries.map((v, i) => {
              const x = (i / (benSeries.length - 1)) * W;
              const y = H - ((v - min) / range) * (H - 10) - 5;
              return `${x},${y}`;
            }).join(" ");
            const lastVal = benSeries[benSeries.length - 1];
            return (
              <div style={{ ...s.card, marginTop: 24 }}>
                <div style={s.sectionTitle}>Curva de beneficio acumulado</div>
                <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 80 }}>
                  <defs>
                    <linearGradient id="benGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={lastVal >= 0 ? "#27AE60" : "#E74C3C"} stopOpacity="0.3" />
                      <stop offset="100%" stopColor={lastVal >= 0 ? "#27AE60" : "#E74C3C"} stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <line x1="0" y1={H - ((0 - min) / range) * (H - 10) - 5} x2={W} y2={H - ((0 - min) / range) * (H - 10) - 5}
                    stroke="rgba(255,255,255,0.1)" strokeWidth="1" strokeDasharray="3,3" />
                  <polyline points={pts} fill="none" stroke={lastVal >= 0 ? "#27AE60" : "#E74C3C"} strokeWidth="2" strokeLinejoin="round" />
                </svg>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}
