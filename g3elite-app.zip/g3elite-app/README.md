# ⚽ G3 Elite Tracker — Guía de instalación

## Paso a paso para tener la app en tu móvil

---

### 1. Sube el proyecto a Vercel (gratis)

1. Ve a **https://vercel.com** desde tu ordenador
2. Haz clic en **"Sign Up"** → regístrate con tu cuenta de Google o GitHub
3. Una vez dentro, haz clic en **"Add New Project"**
4. Selecciona **"Import from folder"** o arrastra la carpeta `g3elite-app` completa
5. Vercel detecta automáticamente que es React — haz clic en **"Deploy"**
6. Espera 1-2 minutos y te dará una URL como: `https://g3elite-xxxx.vercel.app`

---

### 2. Instala la app en tu móvil

#### En Android (Chrome):
1. Abre la URL en Chrome
2. Toca el menú **⋮** (tres puntos arriba a la derecha)
3. Selecciona **"Añadir a pantalla de inicio"**
4. Ponle el nombre que quieras → **"Añadir"**
5. ¡Aparece el icono en tu pantalla de inicio!

#### En iPhone (Safari):
1. Abre la URL en Safari (importante: NO en Chrome)
2. Toca el botón **compartir** (cuadrado con flecha arriba)
3. Selecciona **"Añadir a pantalla de inicio"**
4. Ponle el nombre → **"Añadir"**
5. ¡Aparece el icono en tu pantalla de inicio!

---

### ¿Qué hace la app?

- **Pestaña Picks**: Introduce tus apuestas. La app calcula automáticamente si pasan el filtro élite y qué pick recomienda.
- **Pestaña Estadísticas**: Ve tu ROI, % acierto, beneficio por tipo de pick y curva de beneficio.
- Los datos se guardan en tu dispositivo (no necesita internet una vez cargada).

---

### Columnas que debes rellenar tú:
| Columna | Qué poner |
|---|---|
| Fecha | Fecha del partido |
| Partido | Local vs Visitante |
| Liga | Ej: Tercera RFEF G3 |
| Cuota | Cuota decimal (ej: 1.85) |
| Stake | Cantidad apostada en € |
| Resultado | W (ganada) / L (perdida) / V (void) |
| Gol L / Gol V | Goles al final del partido |
| Over2.5 L/V % | % histórico over 2.5 de cada equipo |
| BTTS L/V % | % histórico ambos marcan de cada equipo |
| Vic L/V % | % histórico victorias de cada equipo |

### Columnas automáticas (no tocar):
- **Media**: Promedio goles entre ambos equipos
- **Filtro**: ✅ OK si pasa todos los criterios
- **Pick**: Sugerencia de apuesta automática
- **Beneficio**: Ganancia/pérdida calculada

---

¿Problemas? Abre un chat nuevo y pregunta.
